[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=15990126&assignment_repo_type=AssignmentRepo)
# Falta de incentivo a carros elétricos

O nosso projeto visa a partir de uma série de recuros implementados em um software promover o maior incentivo ao mercado de automóveis elétricos nacional.

Uma das bases do projeto é permitir a identificação de pontos de carregamento elétrico a partir da localização do usuário.

## Alunos integrantes da equipe

* João Vitor de Alvarenga Alvares
* Henrique Gonçalves Pimenta Velloso
* Lucca Sander Frisso
* Luciano Gomes Eudes

## Professores responsáveis

* Rommel Vieira Carneiro
* Hayala Nepomuceno Curto
* Ilo Amy Saldanha Rivero
* Walisson Ferreira de Carvalho 



    